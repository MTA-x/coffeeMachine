#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{

    system("clear");
    system("clear");

    system("figlet B");
    sleep(1);
    system("clear");

    system("figlet BY");
    sleep(1);
    system("clear");
    
    system("figlet BYE");
    sleep(1);
    
    exit(1);
    
    return 0;
}